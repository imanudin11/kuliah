/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectUASSmt4;

// 1-IMPORT PLUGIN/FUNGSI
import java.awt.HeadlessException;
import static java.lang.Class.forName;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.xml.transform.Result;
import javax.swing.JOptionPane;


/**
 *
 * @author Ahmad Imanudin
 */
public class dbCon {
//2-DEKLARASI METHOD
    Connection cnn;
    Statement stmt;
    ResultSet rs;
    PreparedStatement st;
    
// 3-BUAT-FUNGSI   
    public dbCon() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
        } catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null, "error inisialisasi Class: "+ e);
        }
        
        try{
            stmt=DriverManager.getConnection("jdbc:mysql://localhost:8889/projectUas","root","root").createStatement();
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "error koneksi ke database: "+ e);
        }
    }
// 4-BUAT METHOD
    
    public ResultSet lihatData(String sql){
       try{
           rs=stmt.executeQuery(sql);
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "Error Query : "+ e);
       }
       return rs;
    }    
// 5-BUAT DML

    public void dmlData(String sql){
        try{
            stmt.executeUpdate(sql);
                       
        }catch(SQLException e){
            System.out.println("Error "+e);
        }
    }
    
    public static void main(String[] args) {
        try{
            dbCon cn = new dbCon();
            JOptionPane.showMessageDialog(null, "Koneksi Sukses");
        } catch(HeadlessException e){
            JOptionPane.showMessageDialog(null, "Koneksi Gagal"+ e);
        }
    }
    
    public static Connection getConnect() throws ClassNotFoundException {
        Connection connection = null;
        if (connection == null) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:8889/projectuas",
            "root",
            "root");
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null,"error koneksi ke database : "+ e);
        }
        }
        return connection;
    }
    
}
