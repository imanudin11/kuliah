/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectUASSmt4;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;



/**
 *
 * @author ahmadimanudin
 */
public class menuUtama extends javax.swing.JFrame {
     ResultSet rs;
     String sql;
     dbCon cn = new dbCon();


    /**
     * Creates new form menuUtama
     */
    public menuUtama() {
        initComponents();
    //    setExtendedState(JFrame.MAXIMIZED_BOTH);
        loadDataPaketBronze();
        loadDataPaketSilver();
        loadDataPaketGold();
        loadDataPaketPremium();
    }

    public void loadDataPaketBronze() {
        try{
         
       //  sql="select * from customer inner join paket on customer.id_paket=paket.id_paket inner join tipeLangganan on customer.id_langganan=tipeLangganan.id_langganan";
         sql="select * from paket where id_paket=1";
         rs=cn.lihatData(sql);
         while(rs.next()){
         String idPaket=rs.getString("id_paket");
         String namaPaket=rs.getString("nama_paket");
         String hargaPaket=rs.getString("harga");
         String quotaEmail=rs.getString("quota_email");
         String maxDomain=rs.getString("max_domain");
         String phoneSupport=rs.getString("phone_support");
         String maxAttachment=rs.getString("max_attachment");
         
         jButtonBronze.setText(namaPaket);
         jLabelHargaB.setText(hargaPaket);
         jLabelQuotaEmailB.setText(quotaEmail);
         jLabelMaxDomainB.setText(maxDomain);
         jLabelPhoneSupportB.setText(phoneSupport);
         jLabelMaxAttachmentB.setText(maxAttachment);
         }
            
        }catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }
    public void loadDataPaketSilver() {
        try{
         
       //  sql="select * from customer inner join paket on customer.id_paket=paket.id_paket inner join tipeLangganan on customer.id_langganan=tipeLangganan.id_langganan";
         sql="select * from paket where id_paket=2";
         rs=cn.lihatData(sql);
         while(rs.next()){
         String idPaket=rs.getString("id_paket");
         String namaPaket=rs.getString("nama_paket");
         String hargaPaket=rs.getString("harga");
         String quotaEmail=rs.getString("quota_email");
         String maxDomain=rs.getString("max_domain");
         String phoneSupport=rs.getString("phone_support");
         String maxAttachment=rs.getString("max_attachment");
         
         jButtonSilver.setText(namaPaket);
         jLabelHargaS.setText(hargaPaket);
         jLabelQuotaEmailS.setText(quotaEmail);
         jLabelMaxDomainS.setText(maxDomain);
         jLabelPhoneSupportS.setText(phoneSupport);
         jLabelMaxAttachmentS.setText(maxAttachment);
         }
           
        }catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }
    public void loadDataPaketGold() {
        try{
         
       //  sql="select * from customer inner join paket on customer.id_paket=paket.id_paket inner join tipeLangganan on customer.id_langganan=tipeLangganan.id_langganan";
         sql="select * from paket where id_paket=3";
         rs=cn.lihatData(sql);
         while(rs.next()){
         String idPaket=rs.getString("id_paket");
         String namaPaket=rs.getString("nama_paket");
         String hargaPaket=rs.getString("harga");
         String quotaEmail=rs.getString("quota_email");
         String maxDomain=rs.getString("max_domain");
         String phoneSupport=rs.getString("phone_support");
         String maxAttachment=rs.getString("max_attachment");
         
         jButtonGold.setText(namaPaket);
         jLabelHargaG.setText(hargaPaket);
         jLabelQuotaEmailG.setText(quotaEmail);
         jLabelMaxDomainG.setText(maxDomain);
         jLabelPhoneSupportG.setText(phoneSupport);
         jLabelMaxAttachmentG.setText(maxAttachment);
         }
            
        }catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }
    public void loadDataPaketPremium() {
        try{
         
       //  sql="select * from customer inner join paket on customer.id_paket=paket.id_paket inner join tipeLangganan on customer.id_langganan=tipeLangganan.id_langganan";
         sql="select * from paket where id_paket=4";
         rs=cn.lihatData(sql);
         while(rs.next()){
         String idPaket=rs.getString("id_paket");
         String namaPaket=rs.getString("nama_paket");
         String hargaPaket=rs.getString("harga");
         String quotaEmail=rs.getString("quota_email");
         String maxDomain=rs.getString("max_domain");
         String phoneSupport=rs.getString("phone_support");
         String maxAttachment=rs.getString("max_attachment");
         
         jButtonPremium.setText(namaPaket);
         jLabelHargaP.setText(hargaPaket);
         jLabelQuotaEmailP.setText(quotaEmail);
         jLabelMaxDomainP.setText(maxDomain);
         jLabelPhoneSupportP.setText(phoneSupport);
         jLabelMaxAttachmentP.setText(maxAttachment);
         }
           
        }catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabelHargaB = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabelQuotaEmailB = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabelMaxDomainB = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabelPhoneSupportB = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabelMaxAttachmentB = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButtonBronze = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel9 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        jLabelHargaS = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabelQuotaEmailS = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabelMaxDomainS = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabelPhoneSupportS = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabelMaxAttachmentS = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButtonSilver = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jPanel10 = new javax.swing.JPanel();
        jLabel78 = new javax.swing.JLabel();
        jLabelHargaG = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabelQuotaEmailG = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabelMaxDomainG = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabelPhoneSupportG = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabelMaxAttachmentG = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButtonGold = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabelHargaP = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabelQuotaEmailP = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabelMaxDomainP = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabelPhoneSupportP = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabelMaxAttachmentP = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButtonPremium = new javax.swing.JButton();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Monaco", 1, 24)); // NOI18N
        jLabel1.setText("Selamat Datang Pada");

        jLabel3.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel3.setText("Rp.");

        jLabelHargaB.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabelHargaB.setText("jLabel4");

        jLabel5.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jLabel5.setText("/ Bulan");

        jLabel6.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel6.setText("Max");

        jLabelQuotaEmailB.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelQuotaEmailB.setText("jLabel7");

        jLabel8.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel8.setText("Email/Bulan");

        jLabel9.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel9.setText("Max");

        jLabelMaxDomainB.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxDomainB.setText("jLabel10");

        jLabel11.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel11.setText("Domain");

        jLabel12.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel12.setText("Phone Support :");

        jLabelPhoneSupportB.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelPhoneSupportB.setText("jLabel13");

        jLabel14.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel14.setText("Max");

        jLabelMaxAttachmentB.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxAttachmentB.setText("jLabel15");

        jLabel16.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel16.setText("Attachment");

        jLabel17.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel17.setText("DKIM Support : Yes");

        jLabel18.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel18.setText("SPF Support : Yes");

        jLabel19.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel19.setText("Virus Check : Yes");

        jLabel20.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel20.setText("Spam Check : Yes");

        jLabel21.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel21.setText("SSL/TLS Support : Yes");

        jLabel22.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel22.setText("Chat/Email Support : Yes");

        jButton1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton1.setText("Order Sekarang");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButtonBronze.setBackground(new java.awt.Color(153, 153, 153));
        jButtonBronze.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jButtonBronze.setText("Bronze");

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelHargaB)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelQuotaEmailB)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel8))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelMaxDomainB)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11))
                            .addComponent(jLabel17)
                            .addComponent(jLabel18)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelPhoneSupportB))
                            .addComponent(jLabel19)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelMaxAttachmentB)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel16))
                            .addComponent(jButton1)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jButtonBronze)))
                .addGap(18, 18, 18)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButtonBronze, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabelHargaB)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabelQuotaEmailB)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabelMaxDomainB)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jLabelPhoneSupportB))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jLabelMaxAttachmentB)
                            .addComponent(jLabel16))
                        .addGap(18, 18, 18)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 12, Short.MAX_VALUE))
                    .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jLabel63.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel63.setText("Rp.");

        jLabelHargaS.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabelHargaS.setText("jLabel4");

        jLabel64.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jLabel64.setText("/ Bulan");

        jLabel65.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel65.setText("Max");

        jLabelQuotaEmailS.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelQuotaEmailS.setText("jLabel7");

        jLabel66.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel66.setText("Email/Bulan");

        jLabel67.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel67.setText("Max");

        jLabelMaxDomainS.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxDomainS.setText("jLabel10");

        jLabel68.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel68.setText("Domain");

        jLabel69.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel69.setText("Phone Support :");

        jLabelPhoneSupportS.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelPhoneSupportS.setText("jLabel13");

        jLabel70.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel70.setText("Max");

        jLabelMaxAttachmentS.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxAttachmentS.setText("jLabel15");

        jLabel71.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel71.setText("Attachment");

        jLabel72.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel72.setText("DKIM Support : Yes");

        jLabel73.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel73.setText("SPF Support : Yes");

        jLabel74.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel74.setText("Virus Check : Yes");

        jLabel75.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel75.setText("Spam Check : Yes");

        jLabel76.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel76.setText("SSL/TLS Support : Yes");

        jLabel77.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel77.setText("Chat/Email Support : Yes");

        jButton5.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton5.setText("Order Sekarang");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButtonSilver.setBackground(new java.awt.Color(204, 204, 204));
        jButtonSilver.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jButtonSilver.setText("Silver");

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel63)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelHargaS)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel64))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel65)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelQuotaEmailS)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel66))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel67)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelMaxDomainS)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel68))
                            .addComponent(jLabel72)
                            .addComponent(jLabel73)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel69)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelPhoneSupportS))
                            .addComponent(jLabel74)
                            .addComponent(jLabel75)
                            .addComponent(jLabel76)
                            .addComponent(jLabel77)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel70)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelMaxAttachmentS)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel71))
                            .addComponent(jButton5)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jButtonSilver)))
                .addGap(18, 18, 18)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButtonSilver, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel63)
                            .addComponent(jLabelHargaS)
                            .addComponent(jLabel64))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel65)
                            .addComponent(jLabelQuotaEmailS)
                            .addComponent(jLabel66))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel67)
                            .addComponent(jLabelMaxDomainS)
                            .addComponent(jLabel68))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel72)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel73)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel74)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel75)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel76)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel77)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel69)
                            .addComponent(jLabelPhoneSupportS))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel70)
                            .addComponent(jLabelMaxAttachmentS)
                            .addComponent(jLabel71))
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 12, Short.MAX_VALUE))
                    .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jLabel78.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel78.setText("Rp.");

        jLabelHargaG.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabelHargaG.setText("jLabel4");

        jLabel79.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jLabel79.setText("/ Bulan");

        jLabel80.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel80.setText("Max");

        jLabelQuotaEmailG.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelQuotaEmailG.setText("jLabel7");

        jLabel81.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel81.setText("Email/Bulan");

        jLabel82.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel82.setText("Max");

        jLabelMaxDomainG.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxDomainG.setText("jLabel10");

        jLabel83.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel83.setText("Domain");

        jLabel84.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel84.setText("Phone Support :");

        jLabelPhoneSupportG.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelPhoneSupportG.setText("jLabel13");

        jLabel85.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel85.setText("Max");

        jLabelMaxAttachmentG.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxAttachmentG.setText("jLabel15");

        jLabel86.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel86.setText("Attachment");

        jLabel87.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel87.setText("DKIM Support : Yes");

        jLabel88.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel88.setText("SPF Support : Yes");

        jLabel89.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel89.setText("Virus Check : Yes");

        jLabel90.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel90.setText("Spam Check : Yes");

        jLabel91.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel91.setText("SSL/TLS Support : Yes");

        jLabel92.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel92.setText("Chat/Email Support : Yes");

        jButton6.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton6.setText("Order Sekarang");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButtonGold.setBackground(new java.awt.Color(255, 204, 0));
        jButtonGold.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jButtonGold.setForeground(new java.awt.Color(255, 255, 255));
        jButtonGold.setText("Gold");

        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator7.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel80)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelQuotaEmailG)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel81))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel82)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelMaxDomainG)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel83))
                    .addComponent(jLabel87)
                    .addComponent(jLabel88)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel84)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelPhoneSupportG))
                    .addComponent(jLabel89)
                    .addComponent(jLabel90)
                    .addComponent(jLabel91)
                    .addComponent(jLabel92)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel85)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelMaxAttachmentG)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel86))
                    .addComponent(jButton6)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel78)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonGold)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabelHargaG)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel79)))))
                .addGap(18, 18, 18)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButtonGold, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel78)
                            .addComponent(jLabelHargaG)
                            .addComponent(jLabel79))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel80)
                            .addComponent(jLabelQuotaEmailG)
                            .addComponent(jLabel81))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel82)
                            .addComponent(jLabelMaxDomainG)
                            .addComponent(jLabel83))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel87)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel88)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel89)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel90)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel91)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel92)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel84)
                            .addComponent(jLabelPhoneSupportG))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel85)
                            .addComponent(jLabelMaxAttachmentG)
                            .addComponent(jLabel86))
                        .addGap(19, 19, 19)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 18, Short.MAX_VALUE))
                    .addComponent(jSeparator6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator7, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jLabel4.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel4.setText("Rp.");

        jLabelHargaP.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabelHargaP.setText("jLabel4");

        jLabel7.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jLabel7.setText("/ Bulan");

        jLabel10.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel10.setText("Max");

        jLabelQuotaEmailP.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelQuotaEmailP.setText("jLabel7");

        jLabel13.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel13.setText("Email/Bulan");

        jLabel15.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel15.setText("Max");

        jLabelMaxDomainP.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxDomainP.setText("jLabel10");

        jLabel23.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel23.setText("Domain");

        jLabel24.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel24.setText("Phone Support :");

        jLabelPhoneSupportP.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelPhoneSupportP.setText("jLabel13");

        jLabel25.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel25.setText("Max");

        jLabelMaxAttachmentP.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabelMaxAttachmentP.setText("jLabel15");

        jLabel26.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel26.setText("Attachment");

        jLabel27.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel27.setText("DKIM Support : Yes");

        jLabel28.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel28.setText("SPF Support : Yes");

        jLabel29.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel29.setText("Virus Check : Yes");

        jLabel30.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel30.setText("Spam Check : Yes");

        jLabel31.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel31.setText("SSL/TLS Support : Yes");

        jLabel32.setFont(new java.awt.Font("Ubuntu", 0, 14)); // NOI18N
        jLabel32.setText("Chat/Email Support : Yes");

        jButton2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton2.setText("Order Sekarang");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButtonPremium.setBackground(new java.awt.Color(0, 0, 153));
        jButtonPremium.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jButtonPremium.setForeground(new java.awt.Color(255, 255, 255));
        jButtonPremium.setText("Premium");

        jSeparator8.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelHargaP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelQuotaEmailP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelMaxDomainP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel23))
                    .addComponent(jLabel27)
                    .addComponent(jLabel28)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelPhoneSupportP))
                    .addComponent(jLabel29)
                    .addComponent(jLabel30)
                    .addComponent(jLabel31)
                    .addComponent(jLabel32)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelMaxAttachmentP)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel26))
                    .addComponent(jButton2)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButtonPremium)))
                .addGap(18, 18, 18)
                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jButtonPremium, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabelHargaP)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabelQuotaEmailP)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabelMaxDomainP)
                            .addComponent(jLabel23))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(jLabelPhoneSupportP))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(jLabelMaxAttachmentP)
                            .addComponent(jLabel26))
                        .addGap(19, 19, 19)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 18, Short.MAX_VALUE))
                    .addComponent(jSeparator8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jTextArea1.setBackground(new java.awt.Color(238, 238, 238));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("PT. Excellent Infotama Kreasindo\nRuko Premier Serenity Blok J No. 12 Jl. KH Agus Salim No 40 E Bekasi Jaya\nBekasi Timur, Bekasi 17112\nJawa Barat, Indonesia\n\nTelp : 021 82678811\nHP : 0812 1838 4287\nEmail : sales@excellent.co.id");
        jScrollPane1.setViewportView(jTextArea1);

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel2.setText("Kontak Kami");

        jLabel33.setFont(new java.awt.Font("Monaco", 1, 24)); // NOI18N
        jLabel33.setText("Layanan Excellent SMTP Relay");

        jMenu1.setText("Portal Login");

        jMenuItem1.setText("Login Admin");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Login Customer");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(330, 330, 330))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(399, 399, 399)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String a="Bronze";
        getCustomerDetail.setPaket(a);
        new tambahCustomer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        String a="Silver";
        getCustomerDetail.setPaket(a);
        new tambahCustomer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        String a="Gold";
        getCustomerDetail.setPaket(a);
        new tambahCustomer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String a="Premium";
        getCustomerDetail.setPaket(a);
        new tambahCustomer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new loginAdmin().setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new loginCustomer().setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuUtama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButtonBronze;
    private javax.swing.JButton jButtonGold;
    private javax.swing.JButton jButtonPremium;
    private javax.swing.JButton jButtonSilver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabelHargaB;
    private javax.swing.JLabel jLabelHargaG;
    private javax.swing.JLabel jLabelHargaP;
    private javax.swing.JLabel jLabelHargaS;
    private javax.swing.JLabel jLabelMaxAttachmentB;
    private javax.swing.JLabel jLabelMaxAttachmentG;
    private javax.swing.JLabel jLabelMaxAttachmentP;
    private javax.swing.JLabel jLabelMaxAttachmentS;
    private javax.swing.JLabel jLabelMaxDomainB;
    private javax.swing.JLabel jLabelMaxDomainG;
    private javax.swing.JLabel jLabelMaxDomainP;
    private javax.swing.JLabel jLabelMaxDomainS;
    private javax.swing.JLabel jLabelPhoneSupportB;
    private javax.swing.JLabel jLabelPhoneSupportG;
    private javax.swing.JLabel jLabelPhoneSupportP;
    private javax.swing.JLabel jLabelPhoneSupportS;
    private javax.swing.JLabel jLabelQuotaEmailB;
    private javax.swing.JLabel jLabelQuotaEmailG;
    private javax.swing.JLabel jLabelQuotaEmailP;
    private javax.swing.JLabel jLabelQuotaEmailS;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables

}
