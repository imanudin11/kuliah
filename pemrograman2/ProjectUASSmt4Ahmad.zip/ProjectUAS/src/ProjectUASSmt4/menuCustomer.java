/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ProjectUASSmt4;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.xml.transform.Result;

/**
 *
 * @author ahmadimanudin
 */
public class menuCustomer extends javax.swing.JFrame {
    dbCon cn = new dbCon();
    ResultSet rs,rs2;
    String sql,sql2;
    String email = getCustomerDetail.getUserLogin();
    String noCust = getCustomerDetail.getNo_cust();
    

    /** Creates new form informasiCustomer */
    public menuCustomer() {
        initComponents();
        jTextFieldDomain.setText("");
        dataCustomer();
        hapusDomainTable();
        listDomainTable();
        disableText();
         
    }
    
    public void dataCustomer(){
        try{
                
                //sql="select * from customer where email='"+email+"'";
                sql="select * from customer c inner join transaksi t on c.id_cust=t.id_cust inner join paket p on t.id_paket=p.id_paket inner join tipeLangganan tl on t.id_langganan=tl.id_langganan where c.id_cust='"+noCust+"'";
                rs=cn.lihatData(sql);
                
                while(rs.next()){
                     String nDepan=rs.getString("nama_depan");
                     String nBelakang=rs.getString("nama_belakang");
                     String nCustomer=rs.getString("nama_customer");
                     String alamatCustomer=rs.getString("alamat_customer");
                     String email=rs.getString("email");
                     String phone=rs.getString("phone");
                    // String noCust=rs.getString("id_cust");
                     String paket=rs.getString("nama_paket");
                     String tl=rs.getString("tipe_langganan");
                     String masaAktif=rs.getString("masa_aktif");
                     String harga=rs.getString("harga");
                     String maksDomain=rs.getString("max_domain");
                    // String noPaket=rs.getString("id_paket");
                    // String noLangganan=rs.getString(id_paket);
                     //String id
                     
                      
                     
                     // GetSet
                     //getCustomerDetail.setSurel(rs.getString(eMail));
                     getCustomerDetail.setSurel(email);
                     getCustomerDetail.setNo_cust(noCust);
                     getCustomerDetail.setMaxDomain(maksDomain);
                     getCustomerDetail.setPaket(paket);
                     getCustomerDetail.setLgn(tl);
                     
                     jTextFieldNamaDepan.setText(nDepan);
                     jTextFieldNamaBelakang.setText(nBelakang);
                     jLabelNamaCustomer.setText(nCustomer);
                     jTextAreaAlamat.setText(alamatCustomer);
                     jTextFieldEmail.setText(email);
                     jTextFieldInstansi.setText(nCustomer);
                     jLabelNamaCustomerLogin.setText(nCustomer);
                     jLabelNamaPaket.setText(paket);
                     jLabelTipeLangganan.setText(tl);
                     jLabelMasaAktif.setText(masaAktif);
                     jTextFieldBiayaLangganan.setText(harga);
                     jLabelMaxDomain.setText(maksDomain);
                     
                }
                sql="select count(nama_domain) nama_domain from customer c inner join domain d on c.id_cust=d.id_cust where d.id_cust='"+noCust+"'";
                rs=cn.lihatData(sql);
                while(rs.next()){
                    
                    String domainTerpakai=rs.getString("nama_domain");
                    jLabelDomTerpakai.setText(domainTerpakai);
                }
                
        } catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }
    
    public void disableText(){
//                     jTextFieldNamaDepan.setEnabled(false);
//                     jTextFieldNamaBelakang.setEnabled(false);
//                     jTextFieldInstansi.setEnabled(false);
//                     jTextAreaAlamat.setEnabled(false);
//                     jTextFieldEmail.setEnabled(false);
//                     jTextFieldBiayaLangganan.setEnabled(false);
                     jButtonSimpan.setEnabled(false);
                     
    }
    public void enableText(){
                     jTextFieldNamaDepan.setEnabled(true);
                     jTextFieldNamaBelakang.setEnabled(true);
                     jTextFieldInstansi.setEnabled(true);
                     jTextAreaAlamat.setEnabled(true);
                     jTextFieldEmail.setEnabled(true);
                     jTextFieldBiayaLangganan.setEnabled(true);
                     jButtonSimpan.setEnabled(true);
                     
    }
    
    
    public void hapusDomainTable() {
        int row=jTableDomain.getRowCount();
        DefaultTableModel model = (DefaultTableModel) jTableDomain.getModel();
        for (int i=0; i<row; i++){
            model.removeRow(0);
        }
    }
    public void listDomainTable() {
        DefaultTableModel tbl = (DefaultTableModel) jTableDomain.getModel();
        hapusDomainTable();
        try{
                String nocst = getCustomerDetail.getNo_cust();
                sql="select id_domain,nama_domain from customer c inner join domain d on c.id_cust=d.id_cust where d.id_cust='"+noCust+"'";
                rs=cn.lihatData(sql);
                
                String [] header={"ID","List Domain"};
                 tbl.setColumnIdentifiers(header);
                 while(rs.next()){
                     String nod=rs.getString("id_domain");
                     String nd=rs.getString("nama_domain");
                     tbl.addRow(new Object[]{nod,nd});
                 }
        } catch(SQLException e){
            System.out.println("Error : "+e);
        }
    }

    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabelNamaCustomerLogin = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButtonEditProfile = new javax.swing.JButton();
        jButtonGantiPassword = new javax.swing.JButton();
        jButtonUpgradePaket = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabelNamaCustomer = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaAlamat = new javax.swing.JTextArea();
        jLabelNamaPaket = new javax.swing.JLabel();
        jLabelTipeLangganan = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabelMasaAktif = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jTextFieldBiayaLangganan = new javax.swing.JTextField();
        jTextFieldInstansi = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextFieldNamaDepan = new javax.swing.JTextField();
        jTextFieldEmail = new javax.swing.JTextField();
        jTextFieldNamaBelakang = new javax.swing.JTextField();
        jButtonSimpan = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableDomain = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        jButtonEditDomain = new javax.swing.JButton();
        jButtonTambahDomain = new javax.swing.JButton();
        jButtonHapusDomain = new javax.swing.JButton();
        jTextFieldDomain = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabelDomTerpakai = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabelMaxDomain = new javax.swing.JLabel();
        jButtonLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setText("My Profile");

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel2.setText("Selamat Datang ");

        jLabelNamaCustomerLogin.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabelNamaCustomerLogin.setText("jLabel3");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButtonEditProfile.setBackground(new java.awt.Color(255, 255, 255));
        jButtonEditProfile.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jButtonEditProfile.setText("Edit Profile");
        jButtonEditProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditProfileActionPerformed(evt);
            }
        });

        jButtonGantiPassword.setBackground(new java.awt.Color(255, 255, 255));
        jButtonGantiPassword.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jButtonGantiPassword.setText("Ganti Password");
        jButtonGantiPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGantiPasswordActionPerformed(evt);
            }
        });

        jButtonUpgradePaket.setBackground(new java.awt.Color(255, 255, 255));
        jButtonUpgradePaket.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jButtonUpgradePaket.setText("Upgrade Paket");
        jButtonUpgradePaket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpgradePaketActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ProjectUASSmt4/avatar.png"))); // NOI18N

        jLabelNamaCustomer.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabelNamaCustomer.setText("Nama Customer");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonEditProfile)
                        .addGap(26, 26, 26)
                        .addComponent(jButtonGantiPassword)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonUpgradePaket))
                    .addComponent(jLabelNamaCustomer))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton5)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabelNamaCustomer)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonEditProfile)
                    .addComponent(jButtonGantiPassword)
                    .addComponent(jButtonUpgradePaket))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel5.setText("Nama Depan");

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel6.setText("Email");

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel7.setText("Instansi");

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel8.setText("Alamat");

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel9.setText("Paket");

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel10.setText("Tipe Langganan");

        jTextAreaAlamat.setColumns(20);
        jTextAreaAlamat.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jTextAreaAlamat.setRows(5);
        jTextAreaAlamat.setCaretColor(new java.awt.Color(153, 0, 153));
        jTextAreaAlamat.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(jTextAreaAlamat);

        jLabelNamaPaket.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabelNamaPaket.setText("jLabel14");

        jLabelTipeLangganan.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabelTipeLangganan.setText("jLabel15");

        jLabel16.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel16.setText("Masa Aktif");

        jLabelMasaAktif.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabelMasaAktif.setText("jLabel17");

        jLabel24.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel24.setText("Biaya Langganan");

        jTextFieldBiayaLangganan.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jTextFieldBiayaLangganan.setText("jTextField2");

        jTextFieldInstansi.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jTextFieldInstansi.setText("jTextField2");

        jLabel11.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel11.setText("Nama Belakang");

        jTextFieldNamaDepan.setText("jTextField1");

        jTextFieldEmail.setText("jTextField1");

        jTextFieldNamaBelakang.setText("jTextField1");

        jButtonSimpan.setText("Simpan");
        jButtonSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSimpanActionPerformed(evt);
            }
        });

        jButton1.setText("Cancel");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jTextFieldNamaDepan)
                    .addComponent(jTextFieldEmail)
                    .addComponent(jTextFieldInstansi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel16))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelMasaAktif)
                            .addComponent(jLabelTipeLangganan)
                            .addComponent(jLabelNamaPaket)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jLabel11))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jTextFieldBiayaLangganan, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jTextFieldNamaBelakang, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButtonSimpan)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addGap(23, 23, 23))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel11)
                            .addComponent(jTextFieldNamaDepan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTextFieldNamaBelakang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(jLabelNamaPaket)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabelTipeLangganan))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(jLabelMasaAktif))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldBiayaLangganan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonSimpan)
                            .addComponent(jButton1)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jTextFieldInstansi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel18.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel18.setText("Informasi Domain");

        jTableDomain.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableDomain.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDomainMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableDomain);

        jLabel19.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel19.setText("Domain : ");

        jButtonEditDomain.setText("Sunting");
        jButtonEditDomain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditDomainActionPerformed(evt);
            }
        });

        jButtonTambahDomain.setText("Tambah");
        jButtonTambahDomain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTambahDomainActionPerformed(evt);
            }
        });

        jButtonHapusDomain.setText("Hapus");
        jButtonHapusDomain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHapusDomainActionPerformed(evt);
            }
        });

        jTextFieldDomain.setText("jTextField1");

        jLabel20.setFont(new java.awt.Font("Ubuntu", 0, 12)); // NOI18N
        jLabel20.setText("Domain Terpakai");

        jLabelDomTerpakai.setFont(new java.awt.Font("Ubuntu", 0, 12)); // NOI18N
        jLabelDomTerpakai.setText("jLabel21");

        jLabel22.setFont(new java.awt.Font("Ubuntu", 0, 12)); // NOI18N
        jLabel22.setText("dari");

        jLabelMaxDomain.setFont(new java.awt.Font("Ubuntu", 0, 12)); // NOI18N
        jLabelMaxDomain.setText("jLabel23");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel20)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelDomTerpakai)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabelMaxDomain)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jLabel19)
                                .addGap(18, 18, 18)
                                .addComponent(jTextFieldDomain))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jButtonEditDomain)
                                .addGap(27, 27, 27)
                                .addComponent(jButtonTambahDomain)
                                .addGap(26, 26, 26)
                                .addComponent(jButtonHapusDomain)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addComponent(jLabel18))
                .addGap(48, 48, 48))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabelDomTerpakai)
                    .addComponent(jLabel22)
                    .addComponent(jLabelMaxDomain))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(jTextFieldDomain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonEditDomain)
                            .addComponent(jButtonTambahDomain)
                            .addComponent(jButtonHapusDomain)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jButtonLogout.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jButtonLogout.setText("Logout");
        jButtonLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelNamaCustomerLogin)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonLogout))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabelNamaCustomerLogin)
                    .addComponent(jButtonLogout))
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGantiPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGantiPasswordActionPerformed
        // TODO add your handling code here:
        new gantiPasswordCustomer().setVisible(true);
        
    }//GEN-LAST:event_jButtonGantiPasswordActionPerformed

    private void jButtonLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLogoutActionPerformed
        // TODO add your handling code here:
        try{
        // Penambahan pop up untuk konfirmasi
            int x = JOptionPane.showConfirmDialog(rootPane, "Anda yakin ingin keluar?");
            
            if (x==0) {
                this.dispose();
                new menuUtama().setVisible(true);
            }
          
        } catch (Exception e){
            System.out.println("Error "+e);
        } 
    }//GEN-LAST:event_jButtonLogoutActionPerformed

    private void jTableDomainMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDomainMouseClicked
        // TODO add your handling code here:
        ResultSet rsClick;
        int index=jTableDomain.getSelectedRow();
        TableModel model = jTableDomain.getModel();
//        DefaultTableModel tbl = (DefaultTableModel) jTableDomain.getModel();
        int id_dom = Integer.parseInt(model.getValueAt(index, 0).toString());
        
//        sql="select nama_domain from customer c inner join domain d on c.id_cust=d.id_cust where email='"+email+"'";
        sql="select id_domain,nama_domain from domain where id_domain="+id_dom;
        try{
            rsClick=cn.lihatData(sql);
            if(rsClick.next()){
                jTextFieldDomain.setText(rsClick.getString("nama_domain"));
                
                //jButtonEditDomain.setText("Edit Domain");
                
                // Get and Setter  
               getCustomerDetail.setGetDomain(rsClick.getString("nama_domain"));
               
                }
            
         
       //  sql="select * from customer inner join paket on customer.id_paket=paket.id_paket inner join tipeLangganan on customer.id_langganan=tipeLangganan.id_langganan";
          rsClick.close();
        } catch(Exception e){
            System.out.println("Error "+e);
        }
    }//GEN-LAST:event_jTableDomainMouseClicked

    private void jButtonEditDomainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditDomainActionPerformed
        // TODO add your handling code here:
        ResultSet rsClick;
        int index=jTableDomain.getSelectedRow();
        TableModel model = jTableDomain.getModel();
       try{
            String domname=jTextFieldDomain.getText();
            int id_dom = Integer.parseInt(model.getValueAt(index, 0).toString());
            String sql2="select count(nama_domain) nama_domain from domain where nama_domain='"+domname+"'";
            rs=cn.lihatData(sql2);
            
            sql="update domain set nama_domain='"+domname+"' where id_domain="+id_dom;
            while (rs.next()){
                
            Integer a=Integer.parseInt(rs.getString("nama_domain"));
                if (a !=1 ){
                    //JOptionPane.showMessageDialog(null, "Nama Domain belum ada");
                    System.out.println("SQL : "+sql); 
                    cn.dmlData(sql);
                    dataCustomer();
                    listDomainTable();
                    
                } else{
                   JOptionPane.showMessageDialog(null, "Mohon maaf, nama Domain sudah ada"); 
                
          // Cara 2 - akhir  
                }
            }
//            
            
        } catch (Exception e){
            System.out.println("Error "+e);
        }
    }//GEN-LAST:event_jButtonEditDomainActionPerformed

    private void jButtonTambahDomainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTambahDomainActionPerformed
        // TODO add your handling code here:
        try{
            String domname=jTextFieldDomain.getText();
            sql="insert into domain (id_cust,nama_domain) values('"+noCust+"','"+domname+"')";
            String sql2="select count(nama_domain) nama_domain from domain where nama_domain='"+domname+"'";
            rs=cn.lihatData(sql2);
            
            while (rs.next()){
                
            Integer a=Integer.parseInt(rs.getString("nama_domain"));
            Integer b=Integer.parseInt(jLabelDomTerpakai.getText());
            Integer c=Integer.parseInt(jLabelMaxDomain.getText()); 
                if (a !=1 ) {
                    if (b < c){
                        cn.dmlData(sql);
                        dataCustomer();
                        listDomainTable();
                    }else {
                        JOptionPane.showMessageDialog(null, "Mohon maaf, Maksimum jumlah domain sudah terpenuhi. Silakan upgrade tipe paket anda"); 
                    }
                 
               
            } else {
                   JOptionPane.showMessageDialog(null, "Mohon maaf, nama Domain sudah ada"); 
                }
            }
        } catch (Exception e){
            System.out.println("Error "+e);
        }
    }//GEN-LAST:event_jButtonTambahDomainActionPerformed

    private void jButtonHapusDomainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHapusDomainActionPerformed
        // TODO add your handling code here:
        try{
            String domname=jTextFieldDomain.getText();
            sql="delete from domain where nama_domain='"+domname+"' and id_cust="+noCust;
            System.out.println("SQL : "+sql); 
          // Cara 2 - akhir  
            cn.dmlData(sql);
            dataCustomer();
            listDomainTable();
            
        } catch (Exception e){
            System.out.println("Error "+e);
        }
    }//GEN-LAST:event_jButtonHapusDomainActionPerformed

    private void jButtonUpgradePaketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpgradePaketActionPerformed
        // TODO add your handling code here:
        new suntingPaket().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonUpgradePaketActionPerformed

    private void jButtonEditProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditProfileActionPerformed
        // TODO add your handling code here:
        enableText();
    }//GEN-LAST:event_jButtonEditProfileActionPerformed

    private void jButtonSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSimpanActionPerformed
        // TODO add your handling code here:
        try{
         String nmDepan=jTextFieldNamaDepan.getText();
         String nmBelakang=jTextFieldNamaBelakang.getText();
         String nmInstansi=jTextFieldInstansi.getText();
         String alamatCustomer=jTextAreaAlamat.getText();
         String email=jTextFieldEmail.getText();
         
         String sql2="select count(email) email from customer where email='"+email+"'";
            rs=cn.lihatData(sql2);
            System.out.println(sql2);
            
            while (rs.next()){
                
//                if (email.equalsIgnoreCase(rs.getString("email"))){
//                    System.out.println("Alamat email eksis");
                    
                
            Integer a=Integer.parseInt(rs.getString("email"));
                if (a !=1 ){
         
            sql="update customer set nama_depan='"+nmDepan+"',nama_belakang='"+nmBelakang+"',nama_customer='"+nmInstansi+"',alamat_customer='"+alamatCustomer+"',email='"+email+"' where id_cust="+noCust;
            cn.dmlData(sql);
            dataCustomer();
            hapusDomainTable();
            listDomainTable();
            disableText();
                }else{
                   
                    JOptionPane.showMessageDialog(null, "Mohon maaf, alamat email sudah digunakan"); 
                }
            }
         
         } catch (Exception e){
            System.out.println("Error "+e);
        }
         
    }//GEN-LAST:event_jButtonSimpanActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        disableText();
        dataCustomer();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuCustomer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuCustomer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuCustomer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuCustomer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuCustomer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButtonEditDomain;
    private javax.swing.JButton jButtonEditProfile;
    private javax.swing.JButton jButtonGantiPassword;
    private javax.swing.JButton jButtonHapusDomain;
    private javax.swing.JButton jButtonLogout;
    private javax.swing.JButton jButtonSimpan;
    private javax.swing.JButton jButtonTambahDomain;
    private javax.swing.JButton jButtonUpgradePaket;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelDomTerpakai;
    private javax.swing.JLabel jLabelMasaAktif;
    private javax.swing.JLabel jLabelMaxDomain;
    private javax.swing.JLabel jLabelNamaCustomer;
    private javax.swing.JLabel jLabelNamaCustomerLogin;
    private javax.swing.JLabel jLabelNamaPaket;
    private javax.swing.JLabel jLabelTipeLangganan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableDomain;
    private javax.swing.JTextArea jTextAreaAlamat;
    private javax.swing.JTextField jTextFieldBiayaLangganan;
    private javax.swing.JTextField jTextFieldDomain;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldInstansi;
    private javax.swing.JTextField jTextFieldNamaBelakang;
    private javax.swing.JTextField jTextFieldNamaDepan;
    // End of variables declaration//GEN-END:variables

}
