/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectUASSmt4;

/**
 *
 * @author ahmadimanudin
 */
public class getCustomerDetail {
    private static String nm_customer,al_customer,cp,hp,surel,paket,lgn,no_cust,getDomain,userLogin,maxDomain;

    public static String getNm_customer() {
        return nm_customer;
    }

    public static void setNm_customer(String nm_customer) {
        getCustomerDetail.nm_customer = nm_customer;
    }

    public static String getAl_customer() {
        return al_customer;
    }

    public static void setAl_customer(String al_customer) {
        getCustomerDetail.al_customer = al_customer;
    }

    public static String getCp() {
        return cp;
    }

    public static void setCp(String cp) {
        getCustomerDetail.cp = cp;
    }

    public static String getHp() {
        return hp;
    }

    public static void setHp(String hp) {
        getCustomerDetail.hp = hp;
    }

    public static String getSurel() {
        return surel;
    }

    public static void setSurel(String surel) {
        getCustomerDetail.surel = surel;
    }

    public static String getPaket() {
        return paket;
    }

    public static void setPaket(String paket) {
        getCustomerDetail.paket = paket;
    }

    public static String getLgn() {
        return lgn;
    }

    public static void setLgn(String lgn) {
        getCustomerDetail.lgn = lgn;
    }

    public static String getNo_cust() {
        return no_cust;
    }

    public static void setNo_cust(String no_cust) {
        getCustomerDetail.no_cust = no_cust;
    }

    public static String getGetDomain() {
        return getDomain;
    }

    public static void setGetDomain(String getDomain) {
        getCustomerDetail.getDomain = getDomain;
    }

    public static String getUserLogin() {
        return userLogin;
    }

    public static void setUserLogin(String userLogin) {
        getCustomerDetail.userLogin = userLogin;
    }

    public static String getMaxDomain() {
        return maxDomain;
    }

    public static void setMaxDomain(String maxDomain) {
        getCustomerDetail.maxDomain = maxDomain;
    }

    

      
}
